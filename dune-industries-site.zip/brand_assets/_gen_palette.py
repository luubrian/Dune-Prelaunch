from PIL import Image, ImageDraw, ImageFont
import os

FONTS = r"C:\Users\xoisu\AppData\Roaming\Claude\local-agent-mode-sessions\skills-plugin\656170b3-7d98-4585-b613-21a94f9be50c\eb35dcba-5649-4f7d-a580-289aa4298de5\skills\canvas-design\canvas-fonts"

W, H = 2400, 1720
MARGIN = 96
BG = '#0C0A08'

canvas = Image.new('RGB', (W, H), BG)
draw = ImageDraw.Draw(canvas)

font_title  = ImageFont.truetype(os.path.join(FONTS, 'BigShoulders-Bold.ttf'), 118)
font_sub    = ImageFont.truetype(os.path.join(FONTS, 'Jura-Light.ttf'), 22)
font_group  = ImageFont.truetype(os.path.join(FONTS, 'Jura-Light.ttf'), 17)
font_name   = ImageFont.truetype(os.path.join(FONTS, 'Jura-Medium.ttf'), 20)
font_hex    = ImageFont.truetype(os.path.join(FONTS, 'RedHatMono-Regular.ttf'), 15)

DUNE  = '#C9A97A'
RULE  = '#3A3028'
LABEL = '#7A6850'

groups = [
    ("FOUNDATION", [
        {"name": "VOID",      "hex": "#100E0C", "lbl": "#C9A97A", "border": "#3A3028"},
        {"name": "FORGE",     "hex": "#1C1814", "lbl": "#C9A97A", "border": "#3A3028"},
        {"name": "SLAG",      "hex": "#2E2820", "lbl": "#C9A97A", "border": None},
    ]),
    ("TRANSITION", [
        {"name": "DUST",      "hex": "#5C5040", "lbl": "#EDE0C4", "border": None},
        {"name": "SEDIMENT",  "hex": "#8B7355", "lbl": "#F7F2E8", "border": None},
        {"name": "OCHRE",     "hex": "#A8875C", "lbl": "#1C1814", "border": None},
    ]),
    ("DESERT", [
        {"name": "DUNE",      "hex": "#C9A97A", "lbl": "#1C1814", "border": None},
        {"name": "SANDSTONE", "hex": "#DFC49A", "lbl": "#2E2820", "border": None},
        {"name": "BONE",      "hex": "#EDE0C4", "lbl": "#2E2820", "border": None},
    ]),
    ("PURE", [
        {"name": "HAZE",      "hex": "#F7F2E8", "lbl": "#2E2820", "border": None},
        {"name": "CALCITE",   "hex": "#FFFFFF",  "lbl": "#2E2820", "border": None},
    ]),
    ("ACCENT", [
        {"name": "RUST",      "hex": "#7A4A28", "lbl": "#EDE0C4", "border": None},
        {"name": "COPPER",    "hex": "#B87333", "lbl": "#1C1814", "border": None},
    ]),
]

y = MARGIN

# ── Title ──────────────────────────────────────────────────────
draw.text((MARGIN, y), "ARID\u00b7FORGE", font=font_title, fill=DUNE)
bb = draw.textbbox((MARGIN, y), "ARID\u00b7FORGE", font=font_title)
y += bb[3] - bb[1] + 20

# ── Subtitle ───────────────────────────────────────────────────
sub = "DESERT  INDUSTRIAL    \u00b7    COLOR  SYSTEM"
draw.text((MARGIN + 4, y), sub, font=font_sub, fill='#8B7355')
bb = draw.textbbox((MARGIN + 4, y), sub, font=font_sub)
y += bb[3] - bb[1] + 30

# ── Subtitle (bottom-right companion label) ──────────────────
yr_sub = MARGIN + (draw.textbbox((MARGIN, MARGIN), "ARID\u00b7FORGE", font=font_title)[3] - draw.textbbox((MARGIN, MARGIN), "ARID\u00b7FORGE", font=font_title)[1]) // 2 - 10
right_label = "2026"
rbb = draw.textbbox((0, 0), right_label, font=font_group)
draw.text((W - MARGIN - (rbb[2] - rbb[0]), yr_sub), right_label, font=font_group, fill=LABEL)

# ── Horizontal rule ────────────────────────────────────────────
draw.rectangle([MARGIN, y, W - MARGIN, y + 1], fill=RULE)
y += 1 + 40

# ── Thin vertical accent bar (left edge of content) ────────────
groups_start_y = y
# (drawn after layout to know height)

SWATCH_H  = 188
SWATCH_GAP = 10
GROUP_GAP  = 40
LABEL_H    = 28

for gi, (group_label, colors) in enumerate(groups):
    n = len(colors)
    total_w = W - 2 * MARGIN
    sw = (total_w - SWATCH_GAP * (n - 1)) // n

    # Group section label
    draw.text((MARGIN, y), group_label, font=font_group, fill=LABEL)
    y += LABEL_H

    for i, c in enumerate(colors):
        x = MARGIN + i * (sw + SWATCH_GAP)

        # Swatch rectangle
        draw.rectangle([x, y, x + sw, y + SWATCH_H], fill=c['hex'])

        # Border for near-black swatches to separate from background
        if c.get('border'):
            draw.rectangle([x, y, x + sw, y + SWATCH_H], outline=c['border'], width=1)

        # Color name — top-left of swatch
        draw.text((x + 16, y + 14), c['name'], font=font_name, fill=c['lbl'])

        # Hex code — bottom-left of swatch
        draw.text((x + 16, y + SWATCH_H - 32), c['hex'].upper(), font=font_hex, fill=c['lbl'])

    # Gap between groups (not after last)
    if gi < len(groups) - 1:
        y += SWATCH_H + GROUP_GAP
    else:
        y += SWATCH_H

groups_end_y = y

# ── Thin vertical accent bar ───────────────────────────────────
draw.rectangle(
    [MARGIN - 24, groups_start_y, MARGIN - 22, groups_end_y],
    fill='#2E2820'
)

# ── Bottom credit ──────────────────────────────────────────────
credit = "SANDWERX  \u00b7  2026"
credit_y = H - MARGIN - 20
draw.text((MARGIN, credit_y), credit, font=font_group, fill='#2E2820')

# ── Save ───────────────────────────────────────────────────────
output = r"C:\SANDWERX\Marketing\Dune Website\brand_assets\color-palette.png"
canvas.save(output, 'PNG')
print(f"Saved: {output}")
print(f"Canvas: {W}x{H}px")
print(f"Groups end at y={groups_end_y}, bottom margin at y={H - MARGIN}")
