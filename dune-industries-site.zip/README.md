# Dune Industries — Pre-Launch + Careers Site

A two-page static marketing site for Dune Industries.

## Pages

- **`Pre-Launch.html`** — scroll-driven 6-phase animation:
  1. Intro shrink (giant DUNE logo to centered final size)
  2. Pivot to vertical stack
  3. Vertical drill (down with shake + slag particles)
  4. Dark-cover sweep
  5. Horizontal bone-bar drill (with social-icon tether)
  6. "Unearth your future at Dune." reveal + CTA
  - Click-transition out to `careers.html`
  - Easter egg: hover `E → N×4 → crest` on the vertical lockup
  - Built with React 18 + Babel-standalone + Tailwind via CDN — no build step
- **`careers.html`** — job listings with sort/filter, expandable descriptions,
  baseline-rise loaders, smooth scroll via Lenis

## Run locally

```bash
npm install
node serve.mjs            # serves project root at http://localhost:3000
```

Open `http://localhost:3000/Pre-Launch.html`.

## Project structure

```
.
├── Pre-Launch.html             # Animated landing page
├── careers.html                # Job listings page
├── colors_and_type.css         # Brand palette + General Sans font
├── logo-letters/               # Per-glyph PNGs (D, U, N, E, crest) + manifest
├── brand_assets/               # Logo SVG/PNG variants + General Sans font files
├── fonts/                      # Self-hosted webfont copies
└── serve.mjs                   # Tiny static file server
```

## Brand palette

| Token | Hex | Use |
|---|---|---|
| `--color-void` | `#100E0C` | near-black, deepest shadow |
| `--color-slag` | `#2E2820` | dark surface |
| `--color-sediment` | `#8B7355` | warm brown muted text |
| `--color-dune` | `#C9A97A` | warm sand, primary accent (bone bar) |
| `--color-bone` | `#EDE0C4` | bone |
| `--color-haze` | `#F7F2E8` | warm off-white (careers bg) |

Typography: **General Sans** (Fontshare) throughout.
